﻿// EmployeeEntryForm.cs - সম্পূর্ণ সঠিক কোড

using System;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace NotebookWinFormsApp
{
    public partial class EmployeeEntryForm : Form
    {
        private string imagePath = ""; private EmployeeListForm listForm;

        public EmployeeEntryForm()
        {
            InitializeComponent();
            this.Load += EmployeeEntryForm_Load;
        }

        private void EmployeeEntryForm_Load(object sender, EventArgs e)
        {
            cmbMaritalStatus.Items.AddRange(new string[] { "Single", "Married", "Divorced", "Widowed" });
            cmbGender.Items.AddRange(new string[] { "Male", "Female", "Other" });
            txtEmpCode.Text = GenerateNewEmployeeCode();
            txtName.Focus();
        }

        private string GenerateNewEmployeeCode()
        {
            string newCode = "EMP001";
            using (var conn = new SQLiteConnection("Data Source=notebook.db"))
            {
                conn.Open();
                string query = "SELECT MAX(EmpCode) FROM Employee";
                using (var cmd = new SQLiteCommand(query, conn))
                {
                    var result = cmd.ExecuteScalar()?.ToString();
                    if (!string.IsNullOrEmpty(result))
                    {
                        int num = int.Parse(result.Substring(3)) + 1;
                        newCode = "EMP" + num.ToString("D3");
                    }
                }
            }
            return newCode;
        }

        private void ClearFields()
        {
            foreach (Control c in this.Controls)
            {
                if (c is TextBox tb && tb.Name != "txtEmpCode")
                    tb.Text = "";
            }
            cmbGender.SelectedIndex = -1;
            cmbMaritalStatus.SelectedIndex = -1;
            dtpDob.Value = DateTime.Today;
            dtpJoinDate.Value = DateTime.Today;
            picPhoto.Image = null;
            imagePath = "";
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            ClearFields();
            txtEmpCode.Text = GenerateNewEmployeeCode();
            txtName.Focus();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtMobileNo.Text))
            {
                MessageBox.Show("নাম এবং মোবাইল বাধ্যতামূলক", "ত্রুটি", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            byte[] photoBytes = null;
            if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
                photoBytes = File.ReadAllBytes(imagePath);

            using (var conn = new SQLiteConnection("Data Source=notebook.db"))
            {
                conn.Open();
                string query = @"INSERT INTO Employee (EmpCode, Name, FatherName, MotherName, MobileNo, EmergencyContact, NationalId,
                            DateOfBirth, MaritalStatus, Gender, JoinDate, InitialSalary, PresentAddress, PermanentAddress,
                            Note, Photo, CreatedAt)
                         VALUES (@EmpCode, @Name, @FatherName, @MotherName, @MobileNo, @EmergencyContact, @NationalId,
                            @DateOfBirth, @MaritalStatus, @Gender, @JoinDate, @InitialSalary, @PresentAddress,
                            @PermanentAddress, @Note, @Photo, datetime('now'))";

                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EmpCode", txtEmpCode.Text.Trim());
                    cmd.Parameters.AddWithValue("@Name", txtName.Text.Trim());
                    cmd.Parameters.AddWithValue("@FatherName", txtFatherName.Text.Trim());
                    cmd.Parameters.AddWithValue("@MotherName", txtMotherName.Text.Trim());
                    cmd.Parameters.AddWithValue("@MobileNo", txtMobileNo.Text.Trim());
                    cmd.Parameters.AddWithValue("@EmergencyContact", txtEmergencyContact.Text.Trim());
                    cmd.Parameters.AddWithValue("@NationalId", txtNationalId.Text.Trim());
                    cmd.Parameters.AddWithValue("@DateOfBirth", dtpDob.Value.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@MaritalStatus", cmbMaritalStatus.Text);
                    cmd.Parameters.AddWithValue("@Gender", cmbGender.Text);
                    cmd.Parameters.AddWithValue("@JoinDate", dtpJoinDate.Value.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@InitialSalary", txtInitialSalary.Text.Trim());
                    cmd.Parameters.AddWithValue("@PresentAddress", txtPresentAddress.Text.Trim());
                    cmd.Parameters.AddWithValue("@PermanentAddress", txtPermanentAddress.Text.Trim());
                    cmd.Parameters.AddWithValue("@Note", txtNote.Text.Trim());
                    cmd.Parameters.AddWithValue("@Photo", photoBytes ?? (object)DBNull.Value);
                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("তথ্য সফলভাবে সংরক্ষণ হয়েছে", "সফল", MessageBoxButtons.OK, MessageBoxIcon.Information);
            ClearFields();
            txtEmpCode.Text = GenerateNewEmployeeCode();
            txtName.Focus();
        }

        public void LoadEmployeeFromList(string empCode, string name, string mobile, string presentAddress, string permanentAddress, byte[] photo, string fatherName, string motherName)
        {
            txtEmpCode.Text = empCode;
            txtName.Text = name;
            txtMobileNo.Text = mobile;
            txtPresentAddress.Text = presentAddress;
            txtPermanentAddress.Text = permanentAddress;
            txtFatherName.Text = fatherName;
            txtMotherName.Text = motherName;

            if (photo != null && photo.Length > 0)
            {
                using (MemoryStream ms = new MemoryStream(photo))
                {
                    picPhoto.Image = Image.FromStream(ms);
                }
            }
            else
            {
                picPhoto.Image = null;
            }
        }
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtEmpCode.Text))
            {
                MessageBox.Show("একটি এমপ্লয়ি কোড দিন", "ত্রুটি", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show("আপনি কি নিশ্চিতভাবে এই তথ্য মুছতে চান?", "নিশ্চিতকরণ", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                using (var conn = new SQLiteConnection("Data Source=notebook.db"))
                {
                    conn.Open();
                    string query = "DELETE FROM Employee WHERE EmpCode = @EmpCode";
                    using (var cmd = new SQLiteCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@EmpCode", txtEmpCode.Text.Trim());
                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("তথ্য সফলভাবে মুছে ফেলা হয়েছে", "সফল", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClearFields();
                            txtEmpCode.Text = GenerateNewEmployeeCode();
                            txtName.Focus();
                        }
                        else
                        {
                            MessageBox.Show("এই কোডে কোন তথ্য খুঁজে পাওয়া যায়নি", "ত্রুটি", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Image Files|*.jpg;*.jpeg;*.png";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    imagePath = ofd.FileName;
                    picPhoto.Image = Image.FromFile(imagePath);
                }
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            picPhoto.Image = null;
            imagePath = "";
        }

        private void btnGetData_Click(object sender, EventArgs e)
        {
            if (listForm == null || listForm.IsDisposed)
            {
                listForm = new EmployeeListForm();
                listForm.Show();
            }
            else
            {
                listForm.BringToFront();
                listForm.Focus();
            }
        }

        private void btnUpDate_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtEmpCode.Text)) { MessageBox.Show("একটি এমপ্লয়ি কোড দিন", "ত্রুটি", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }

            using (var conn = new SQLiteConnection("Data Source=notebook.db"))
            {
                conn.Open();
                string query = @"UPDATE Employee SET 
                        Name = @Name,
                        FatherName = @FatherName,
                        MotherName = @MotherName,
                        MobileNo = @MobileNo,
                        EmergencyContact = @EmergencyContact,
                        NationalId = @NationalId,
                        DateOfBirth = @DateOfBirth,
                        MaritalStatus = @MaritalStatus,
                        Gender = @Gender,
                        JoinDate = @JoinDate,
                        InitialSalary = @InitialSalary,
                        PresentAddress = @PresentAddress,
                        PermanentAddress = @PermanentAddress,
                        Note = @Note,
                        Photo = @Photo
                    WHERE EmpCode = @EmpCode";

                byte[] photoBytes = null;
                if (!string.IsNullOrEmpty(imagePath) && File.Exists(imagePath))
                    photoBytes = File.ReadAllBytes(imagePath);

                using (var cmd = new SQLiteCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@EmpCode", txtEmpCode.Text.Trim());
                    cmd.Parameters.AddWithValue("@Name", txtName.Text.Trim());
                    cmd.Parameters.AddWithValue("@FatherName", txtFatherName.Text.Trim());
                    cmd.Parameters.AddWithValue("@MotherName", txtMotherName.Text.Trim());
                    cmd.Parameters.AddWithValue("@MobileNo", txtMobileNo.Text.Trim());
                    cmd.Parameters.AddWithValue("@EmergencyContact", txtEmergencyContact.Text.Trim());
                    cmd.Parameters.AddWithValue("@NationalId", txtNationalId.Text.Trim());
                    cmd.Parameters.AddWithValue("@DateOfBirth", dtpDob.Value.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@MaritalStatus", cmbMaritalStatus.Text);
                    cmd.Parameters.AddWithValue("@Gender", cmbGender.Text);
                    cmd.Parameters.AddWithValue("@JoinDate", dtpJoinDate.Value.ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue("@InitialSalary", txtInitialSalary.Text.Trim());
                    cmd.Parameters.AddWithValue("@PresentAddress", txtPresentAddress.Text.Trim());
                    cmd.Parameters.AddWithValue("@PermanentAddress", txtPermanentAddress.Text.Trim());
                    cmd.Parameters.AddWithValue("@Note", txtNote.Text.Trim());
                    cmd.Parameters.AddWithValue("@Photo", photoBytes ?? (object)DBNull.Value);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("তথ্য সফলভাবে আপডেট হয়েছে", "সফল", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        ClearFields();
                        txtEmpCode.Text = GenerateNewEmployeeCode();
                        txtName.Focus();
                    }
                    else
                    {
                        MessageBox.Show("এই কোডে কোন তথ্য খুঁজে পাওয়া যায়নি", "ত্রুটি", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
        }
    }
}
