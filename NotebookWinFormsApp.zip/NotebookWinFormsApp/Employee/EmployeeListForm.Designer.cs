﻿// EmployeeListForm.Designer.cs + EmployeeListForm.cs Combined (Final UI + Logic)

using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace NotebookWinFormsApp
{
    public partial class EmployeeListForm : Form
    {
        private System.ComponentModel.IContainer components = null; private TextBox txtSearch; private DataGridView dataGridView1; private PictureBox picPhoto; private TextBox txtPresentAddress; private TextBox txtPermanentAddress;

        private DataTable employeeTable;

        public EmployeeListForm()
        {
            InitializeComponent();
            Load += EmployeeListForm_Load;
        }

        private void InitializeComponent()
        {
            txtSearch = new TextBox();
            dataGridView1 = new DataGridView();
            ColEmpCode = new DataGridViewTextBoxColumn();
            ColName = new DataGridViewTextBoxColumn();
            ColMobileNo = new DataGridViewTextBoxColumn();
            ColFatherName = new DataGridViewTextBoxColumn();
            ColMatherName = new DataGridViewTextBoxColumn();
            ColNote = new DataGridViewTextBoxColumn();
            picPhoto = new PictureBox();
            txtPresentAddress = new TextBox();
            txtPermanentAddress = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)picPhoto).BeginInit();
            SuspendLayout();
            // 
            // txtSearch
            // 
            txtSearch.Font = new Font("Segoe UI", 10F, FontStyle.Regular, GraphicsUnit.Point);
            txtSearch.Location = new Point(12, 12);
            txtSearch.Name = "txtSearch";
            txtSearch.PlaceholderText = "Search by Name / Mobile / Address";
            txtSearch.Size = new Size(400, 25);
            txtSearch.TabIndex = 0;
            txtSearch.TextChanged += txtSearch_TextChanged;
            txtSearch.KeyDown += txtSearch_KeyDown;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { ColEmpCode, ColName, ColMobileNo, ColFatherName, ColMatherName, ColNote });
            dataGridView1.Location = new Point(12, 45);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.Size = new Size(700, 350);
            dataGridView1.TabIndex = 1;
            dataGridView1.CellDoubleClick += dataGridView1_CellDoubleClick;
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
            dataGridView1.KeyDown += dataGridView1_KeyDown;
            // 
            // ColEmpCode
            // 
            ColEmpCode.DataPropertyName = "EmpCode";
            ColEmpCode.HeaderText = "EmpCode";
            ColEmpCode.Name = "ColEmpCode";
            ColEmpCode.ReadOnly = true;
            // 
            // ColName
            // 
            ColName.DataPropertyName = "Name";
            ColName.HeaderText = "Name";
            ColName.Name = "ColName";
            ColName.ReadOnly = true;
            // 
            // ColMobileNo
            // 
            ColMobileNo.DataPropertyName = "MobileNo";
            ColMobileNo.HeaderText = "Mobile No";
            ColMobileNo.Name = "ColMobileNo";
            ColMobileNo.ReadOnly = true;
            // 
            // ColFatherName
            // 
            ColFatherName.DataPropertyName = "FatherName";
            ColFatherName.HeaderText = "Father Name";
            ColFatherName.Name = "ColFatherName";
            ColFatherName.ReadOnly = true;
            // 
            // ColMatherName
            // 
            ColMatherName.DataPropertyName = "MatherName";
            ColMatherName.HeaderText = "Mather Name";
            ColMatherName.Name = "ColMatherName";
            ColMatherName.ReadOnly = true;
            // 
            // ColNote
            // 
            ColNote.DataPropertyName = "Note";
            ColNote.HeaderText = "Note";
            ColNote.Name = "ColNote";
            ColNote.ReadOnly = true;
            // 
            // picPhoto
            // 
            picPhoto.BorderStyle = BorderStyle.FixedSingle;
            picPhoto.Location = new Point(730, 45);
            picPhoto.Name = "picPhoto";
            picPhoto.Size = new Size(140, 140);
            picPhoto.SizeMode = PictureBoxSizeMode.StretchImage;
            picPhoto.TabIndex = 2;
            picPhoto.TabStop = false;
            // 
            // txtPresentAddress
            // 
            txtPresentAddress.Location = new Point(730, 200);
            txtPresentAddress.Multiline = true;
            txtPresentAddress.Name = "txtPresentAddress";
            txtPresentAddress.PlaceholderText = "Present Address";
            txtPresentAddress.ReadOnly = true;
            txtPresentAddress.Size = new Size(250, 60);
            txtPresentAddress.TabIndex = 3;
            // 
            // txtPermanentAddress
            // 
            txtPermanentAddress.Location = new Point(730, 270);
            txtPermanentAddress.Multiline = true;
            txtPermanentAddress.Name = "txtPermanentAddress";
            txtPermanentAddress.PlaceholderText = "Permanent Address";
            txtPermanentAddress.ReadOnly = true;
            txtPermanentAddress.Size = new Size(250, 60);
            txtPermanentAddress.TabIndex = 4;
            // 
            // EmployeeListForm
            // 
            ClientSize = new Size(1000, 420);
            Controls.Add(txtSearch);
            Controls.Add(dataGridView1);
            Controls.Add(picPhoto);
            Controls.Add(txtPresentAddress);
            Controls.Add(txtPermanentAddress);
            Name = "EmployeeListForm";
            Text = "Employee List";
            Load += EmployeeListForm_Load_1;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)picPhoto).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }
        private DataGridViewTextBoxColumn ColEmpCode;
        private DataGridViewTextBoxColumn ColName;
        private DataGridViewTextBoxColumn ColMobileNo;
        private DataGridViewTextBoxColumn ColFatherName;
        private DataGridViewTextBoxColumn ColMatherName;
        private DataGridViewTextBoxColumn ColNote;

        // ... (rest of logic remains unchanged)
    }

}