﻿// Final EmployeeListForm.cs (using Designer columns only, with sample rows)

using System;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace NotebookWinFormsApp
{
    public partial class EmployeeListForm : Form
    {
        private DataTable empTable;

        public EmployeeListForm()
        {
            InitializeComponent();
            Load += EmployeeListForm_Load;
        }

        private void EmployeeListForm_Load(object sender, EventArgs e)
        {
            dataGridView1.AutoGenerateColumns = false;
            LoadEmployeeList();
            txtSearch.Focus();
        }

        private void LoadEmployeeList()
        {
            empTable = new DataTable();

            // শুধু Row Add করবো, Column Designer থেকে আসবে
            empTable.Rows.Add("EMP001", "Sujon", "017XXXXXXXX", "Father1", "Mother1", "Note 1", "Dhaka", "Chittagong", null);
            empTable.Rows.Add("EMP002", "Shamim", "018XXXXXXXX", "Father2", "Mother2", "Note 2", "Rajshahi", "Khulna", null);
            empTable.Rows.Add("EMP003", "Nasir", "019XXXXXXXX", "Father3", "Mother3", "Note 3", "Barisal", "Sylhet", null);

            dataGridView1.DataSource = empTable.DefaultView;
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtSearch.Text.Trim().ToLower();
            var filtered = empTable.AsEnumerable().Where(row =>
                row["Name"].ToString().ToLower().Contains(searchText) ||
                row["MobileNo"].ToString().ToLower().Contains(searchText) ||
                row["PresentAddress"].ToString().ToLower().Contains(searchText) ||
                row["PermanentAddress"].ToString().ToLower().Contains(searchText));

            if (filtered.Any())
                dataGridView1.DataSource = filtered.CopyToDataTable().DefaultView;
        }

        private void txtSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && dataGridView1.Rows.Count > 0)
            {
                dataGridView1.Focus();
                dataGridView1.CurrentCell = dataGridView1.Rows[0].Cells[0];
                e.Handled = true;
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow != null)
            {
                var row = dataGridView1.CurrentRow;
                txtPresentAddress.Text = row.Cells["PresentAddress"].Value.ToString();
                txtPermanentAddress.Text = row.Cells["PermanentAddress"].Value.ToString();

                byte[] photo = row.Cells["Photo"].Value as byte[];
                if (photo != null && photo.Length > 0)
                {
                    using (MemoryStream ms = new MemoryStream(photo))
                    {
                        picPhoto.Image = Image.FromStream(ms);
                    }
                }
                else
                {
                    picPhoto.Image = null;
                }
            }
        }

        private void dataGridView1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && dataGridView1.CurrentRow != null)
            {
                LoadSelectedEmployee();
                e.Handled = true;
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                LoadSelectedEmployee();
            }
        }

        private void LoadSelectedEmployee()
        {
            var row = dataGridView1.CurrentRow;
            if (row != null)
            {
                string empCode = row.Cells["EmpCode"].Value.ToString();
                string name = row.Cells["Name"].Value.ToString();
                string mobile = row.Cells["MobileNo"].Value.ToString();
                string presentAddress = row.Cells["PresentAddress"].Value.ToString();
                string permanentAddress = row.Cells["PermanentAddress"].Value.ToString();
                byte[] photo = row.Cells["Photo"].Value as byte[];
                string fatherName = row.Cells["FatherName"].Value.ToString();
                string motherName = row.Cells["MotherName"].Value.ToString();

                foreach (Form form in Application.OpenForms)
                {
                    if (form is EmployeeEntryForm entryForm)
                    {
                        entryForm.LoadEmployeeFromList(empCode, name, mobile, presentAddress, permanentAddress, photo, fatherName, motherName);
                        this.Close();
                        return;
                    }
                }

                EmployeeEntryForm newForm = new EmployeeEntryForm();
                newForm.LoadEmployeeFromList(empCode, name, mobile, presentAddress, permanentAddress, photo, fatherName, motherName);
                newForm.Show();
                this.Close();
            }
        }
    }

}